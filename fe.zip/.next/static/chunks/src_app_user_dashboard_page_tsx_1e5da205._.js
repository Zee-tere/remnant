(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_user_dashboard_page_tsx_1e5da205._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_user_dashboard_page_tsx_1e5da205._.js",
  "chunks": [
    "static/chunks/src_f6551a13._.js",
    "static/chunks/node_modules_49353354._.js"
  ],
  "source": "dynamic"
});
